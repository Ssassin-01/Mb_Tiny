import React from 'react';

function MainPage() {
  return <h1>메인 페이지입니다</h1>;
}

export default MainPage;
